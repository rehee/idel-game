﻿namespace Web
{
    public class Options
    {
        public string ApiUrl { get; set; }
    }
}